<h1 align="center">Welcome to Huyền Thoại Hải Tặc _Server_Termux </h1>
<img alt="7" src="https://github.com/haitac4754/huyenthoaihaitac/blob/main/image/7.png" />
<img alt="Homepage" src="https://github.com/haitac4754/huyenthoaihaitac/blob/main/image/5.png" />
  Chìa khóa Huyền Thoại hải tặc server termux

 - key sẽ bị xóa khỏi hệ thống sau khi cài đặt thành công
 - thời gian sử dụng vĩnh viễn
 - mua key [tại đây](https://gmtoolgame.tudong.pro/keyhtht)  
 - Giá key 100k
 - hướng dẫn sử dụng : [tại đây](https://gmtoolgame.tudong.pro/termx-cai-dat)

## Install
 - Hướng dẫn cài đặt: [tại đây](https://gmtoolgame.tudong.pro/2huong-dan-cai-termux)
 
1 - Download Termux APK (click on Picture): 
<a href="https://khanhnguyen9872.github.io/Ninja_Server_Termux/CONF_FILE/termux_0.118.apk" target="_blank">
    <img alt="Termux" src="https://github.com/KhanhNguyen9872/Ninja_Server_Termux/raw/main/image/termux.png" />
</a>

2 - Install Termux APK

3 - Open Termux, copy this line and paste it on Termux

```bash
function install () {
  clear; curl -L --max-redirs 15 --progress-bar "https://raw.githubusercontent.com/haitac4754/huyenthoaihaitac/main/script_install2.sh" --output script_install2.sh && bash script_install2.sh || echo "Internet ERROR"; unset install
}
install
```

4 - Wait for install!
 
5 - Choose Source you want to use! 
 
6 - Enjoy!
<img alt="Homepage" src="https://github.com/haitac4754/huyenthoaihaitac/blob/main/image/6.png" />
<img alt="Homepage" src="https://github.com/haitac4754/huyenthoaihaitac/blob/main/image/4.png" />
<img alt="Homepage" src="https://github.com/haitac4754/huyenthoaihaitac/blob/main/image/1.png" />
<img alt="Homepage" src="https://github.com/haitac4754/huyenthoaihaitac/blob/main/image/2.png" />
<img alt="Homepage" src="https://github.com/haitac4754/huyenthoaihaitac/blob/main/image/3.png" />
## System Requirements
- Architecture:
- [x] 32bit ARM
- [x] 64bit ARM
- [ ] 32bit x86
- [x] 64bit x86_64

- Android:
- [x] 7
- [x] 8
- [x] 9
- [x] 10
- [x] 11
- [x] 12 
- [ ] 13
- [ ] 14

## Download Emulator (x86_64)

<a href="https://github.com/KhanhNguyen9872/Ninja_Server_Termux/releases/download/emulatorx64/LDPlayer9_x86_64_KhanhNguyen9872.exe" target="_blank">
    <img alt="LDPlayer9" src="https://github.com/KhanhNguyen9872/Ninja_Server_Termux/blob/main/image/ldplayer9.ico?raw=true" width="150" height="150" />
</a>

- [LDPlayer9](https://github.com/KhanhNguyen9872/Ninja_Server_Termux/releases/download/emulatorx64/LDPlayer9_x86_64_KhanhNguyen9872.exe)

## Author

👤 **haitac4754**

* Website: (https://gmtoolgame.tudong.pro/ )
* Github: [@haitac4754](https://github.com/haitac4754)

## 📝 License

Copyright © 2022 (https://github.com/haitac4754).<br />
This project is [haitac4754]((https://github.com/haitac4754)) licensed.

***
