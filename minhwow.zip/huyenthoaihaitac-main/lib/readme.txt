An indispensable component when running a script
